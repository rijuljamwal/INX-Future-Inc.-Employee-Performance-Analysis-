# References Folder

This folder contains supporting information and notes for the IABAC Certified Data Scientist project.

Files:
- data_dictionary.txt → Contains explanation of important dataset columns.
- additional_notes.txt → General notes and assumptions taken during the project.

Prepared by: Rijul Jamwal
For: IABAC Certified Data Scientist Project Submission
